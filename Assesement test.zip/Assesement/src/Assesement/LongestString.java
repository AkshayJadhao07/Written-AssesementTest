package Assesement;


// The Longest Word  String 
import java.util.Scanner;

public class LongestString {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("The Longest String :");
		String a = s.nextLine();

		String str = " ";
		String lg = " ";

		for (int i = 0; i < a.length(); i++) {

			char ch = a.charAt(i);

			if (ch != ' ') {
				str = str + ch;
			} else {
				if (str.length() > lg.length())
					lg = str;

				str = " ";
			}

		}
		
		System.out.println("The longest String :"+lg);
	}

}
