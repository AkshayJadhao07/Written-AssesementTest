package Assesement;
// program that accepts an email string and validates that email.
import java.util.Scanner;

public class Emailvalidator {

	static boolean Emailisvalid(String email) {
		String reg = "^[\\w-_\\.+]*[\\w-_\\.]\\@[\\w-_\\.]+[\\w]+[\\w]*";
		return email.matches(reg);
	}

	public static void main(String[] args) {

		Scanner ss = new Scanner(System.in);
		String email;
		int i;
		for (i = 0; i <= 3; i++) {
			System.out.println(" Enter the Email Address:");

			email = ss.next();
			
			//System.out.println("\n The Email address is :"+email);

			System.out.println("Email Addess is :" + Emailisvalid(email));
			System.out.println();

		}
	}

}
