package Assesement;

//A class that accepts two numbers. Create another class that fetches the last digit of those two numbers. Create a third class that multiplayer that last two digits.

public class A {

	int a;
	int b;

	public A(int a, int b) {
		this.a = a;
		this.b = b;
	}

}

class B {

	public int lastDigit(int x) {
		int c = x % 10;
		return c;
	}

}

class C {

	public int multiplylastdigit(int a, int b) {
		int l1 = a % 10;
		int l2 = b % 10;
		return l1 * l2;
	}
}