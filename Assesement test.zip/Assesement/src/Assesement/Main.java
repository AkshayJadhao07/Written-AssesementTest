package Assesement;

// The main class of accept two number
public class Main {

	public static void main(String[] args) {

		A a = new A(12, 34);

		
		B b=new B();
		int lg1=b.lastDigit(a.a);
		int lg2=b.lastDigit(a.b);
		
		C c=new C();
		
		int result =c.multiplylastdigit(lg1, lg2);
		
		System.out.println(lg1);
		System.out.println(lg2);
		System.out.println(result);
		
	}

}
