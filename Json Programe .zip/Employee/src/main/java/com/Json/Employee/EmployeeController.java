package com.Json.Employee;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeController {

	public static void main(String[] args) throws JsonProcessingException {

		ObjectMapper obj = new ObjectMapper();

		ArrayList<Employee> list = new ArrayList<>();
		Employee e1 = new Employee("abc", "xyz", 1);

		Employee e2 = new Employee("abc", "xyz", 2);

		String emp1 = obj.writeValueAsString(e1);
		String emp2 = obj.writeValueAsString(e2);

		System.out.println("EmployeeData : " + emp1 + " " + emp2);

	}
}
